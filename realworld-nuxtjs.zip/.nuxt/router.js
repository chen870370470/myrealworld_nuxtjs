import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _29daa744 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _4a4b6313 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _014d7096 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _674cfef5 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _1392f057 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _41785abe = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _4e174242 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _29daa744,
    children: [{
      path: "",
      component: _4a4b6313,
      name: "home"
    }, {
      path: "/login",
      component: _014d7096,
      name: "login"
    }, {
      path: "/register",
      component: _014d7096,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _674cfef5,
      name: "profile"
    }, {
      path: "/settings",
      component: _1392f057,
      name: "settings"
    }, {
      path: "/editor",
      component: _41785abe,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _4e174242,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config.app && config.app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
