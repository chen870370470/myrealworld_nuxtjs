const middleware = {}

middleware['notUserenticated'] = require('..\\middleware\\notUserenticated.js')
middleware['notUserenticated'] = middleware['notUserenticated'].default || middleware['notUserenticated']

middleware['userenticated'] = require('..\\middleware\\userenticated.js')
middleware['userenticated'] = middleware['userenticated'].default || middleware['userenticated']

export default middleware
